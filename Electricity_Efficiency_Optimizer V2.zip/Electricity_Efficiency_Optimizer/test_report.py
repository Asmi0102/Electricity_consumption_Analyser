"""Run actual analyzer scenarios and print expected-vs-actual test report."""
from copy import deepcopy
from analyzer import DEFAULT_DATA, analyze_household

def cases():
    normal = deepcopy(DEFAULT_DATA)
    zero = deepcopy(DEFAULT_DATA)
    for c in zero["categories"]: c["reduce_hours_per_day"] = 0
    invalid = deepcopy(DEFAULT_DATA); invalid["categories"][0]["hours_per_day"] = 25
    high = deepcopy(DEFAULT_DATA); high["high_consumption_threshold_kwh"] = 1.0
    return [
        {"title":"Normal household data", "input":normal, "check":lambda r: r.get("ok") and r.get("final_state")=="REPORT_READY" and abs(r.get("total_daily_kwh",0)-7.34)<1e-6 and abs(r.get("total_estimated_cost",0)-1761.6)<1e-6 and abs(r.get("potential_savings_cost",0)-372.0)<1e-6, "expected":"REPORT_READY; daily 7.34 kWh; bill ₹1761.60; savings ₹372.00"},
        {"title":"Zero usage reduction", "input":zero, "check":lambda r: r.get("ok") and r.get("potential_savings_cost")==0 and r.get("final_state")=="REPORT_READY", "expected":"REPORT_READY; savings ₹0.00"},
        {"title":"Invalid operating hours", "input":invalid, "check":lambda r: not r.get("ok") and r.get("final_state")=="INVALID_INPUT" and "at most 24" in r.get("error", ""), "expected":"INVALID_INPUT; understandable hours validation error"},
        {"title":"High-consumption category", "input":high, "check":lambda r: r.get("ok") and "Cooling" in r.get("high_consumption_categories",[]) and r.get("highest_consuming_category")=="Cooling", "expected":"Cooling flagged; highest category Cooling"},
    ]

def format_input(data):
    """Return a compact, readable summary instead of a raw nested dictionary."""
    lines = [
        f"  Tariff: ₹{data['tariff_per_kwh']:.2f}/kWh | Billing days: {data['billing_days']} | "
        f"High-use threshold: {data['high_consumption_threshold_kwh']:.2f} kWh/day",
        "  Categories:",
        f"    {'Category':<16} {'Power (W)':>10} {'Hours/day':>10} {'Reduce/day':>11}",
        f"    {'-'*16} {'-'*10} {'-'*10} {'-'*11}",
    ]
    for item in data['categories']:
        lines.append(
            f"    {item['name']:<16} {item['power_watts']:>10g} "
            f"{item['hours_per_day']:>10g} {item.get('reduce_hours_per_day', 0):>11g}"
        )
    return "\n".join(lines)


def format_actual(result):
    """Show only relevant result fields, with numbers and errors formatted clearly."""
    if not result.get("ok"):
        return [f"  Result      : INVALID_INPUT", f"  Error       : {result.get('error', 'Unknown error')}"]
    return [
        f"  Result      : {result.get('final_state')}",
        f"  Daily usage : {result.get('total_daily_kwh', 0):.3f} kWh/day",
        f"  Bill        : ₹{result.get('total_estimated_cost', 0):,.2f}",
        f"  Savings     : ₹{result.get('potential_savings_cost', 0):,.2f}",
        f"  High-use    : {', '.join(result.get('high_consumption_categories', [])) or 'None'}",
        f"  Highest use : {result.get('highest_consuming_category', 'N/A')}",
    ]


def main():
    passed = failed = 0
    width = 72
    print("\n" + "=" * width)
    print("ELECTRICITY EFFICIENCY OPTIMIZER — TEST REPORT".center(width))
    print("=" * width)
    for i, case in enumerate(cases(), 1):
        actual = analyze_household(case["input"])
        ok = bool(case["check"](actual))
        passed += int(ok)
        failed += int(not ok)
        print(f"\nTEST {i}: {case['title']}")
        print("-" * width)
        print("INPUT")
        print(format_input(case["input"]))
        print(f"\nEXPECTED  : {case['expected']}")
        print("ACTUAL")
        print("\n".join(format_actual(actual)))
        print(f"  FSM path    : {' -> '.join(actual.get('fsm_trace', []))}")
        print(f"\nSTATUS      : {'PASS ✓' if ok else 'FAIL ✗'}")
    total = passed + failed
    print("\n" + "=" * width)
    print("SUMMARY".center(width))
    print("=" * width)
    print(f"Tests run: {total}   Passed: {passed}   Failed: {failed}   "
          f"Pass rate: {passed / total * 100:.1f}%")
    print("=" * width)
    return 0 if failed == 0 else 1

if __name__ == "__main__": raise SystemExit(main())
