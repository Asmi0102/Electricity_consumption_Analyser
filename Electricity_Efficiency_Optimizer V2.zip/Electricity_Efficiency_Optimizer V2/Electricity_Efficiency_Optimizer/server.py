import json
import socket
from analyzer import analyze_household

HOST = "127.0.0.1"
PORT = 50515
MAX_REQUEST_BYTES = 1_000_000


def transition(label):
    print(f"  FSM transition   : {label}", flush=True)


def serve_client(conn, address):
    """Receive one request, print a readable server-side trace, and reply."""
    print(f"\nConnected by {address[0]}:{address[1]}", flush=True)
    conn.settimeout(10)
    try:
        chunks = bytearray()
        while b"\n" not in chunks and len(chunks) <= MAX_REQUEST_BYTES:
            part = conn.recv(4096)
            if not part:
                break
            chunks.extend(part)

        if len(chunks) > MAX_REQUEST_BYTES:
            response = {"ok": False, "error": "Request is too large.", "final_state": "INVALID_INPUT", "fsm_trace": []}
            print("  Request received : oversized request", flush=True)
        elif not chunks.strip():
            response = {"ok": False, "error": "Empty request received.", "final_state": "INVALID_INPUT", "fsm_trace": []}
            print("  Request received : empty request", flush=True)
        else:
            line = bytes(chunks).split(b"\n", 1)[0]
            try:
                request = json.loads(line.decode("utf-8"))
                records = request.get("categories", []) if isinstance(request, dict) else []
                print(f"  Request received : {len(records)} appliance record(s)", flush=True)
                transition("RECEIVED   --valid_data--> VALIDATING")
                response = analyze_household(request)
                if response.get("ok"):
                    transition("VALIDATING --valid_records--> ANALYZING")
                    transition("ANALYZING  --analysis_success--> COMPLETED")
                    print(
                        "  Result           : OK - "
                        f"{response.get('total_period_kwh', 0):.3f} kWh/month, "
                        f"Rs {response.get('total_estimated_cost', 0):.2f}",
                        flush=True,
                    )
                else:
                    print(f"  Result           : INVALID_INPUT - {response.get('error', 'Invalid request')}", flush=True)
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                response = {"ok": False, "error": f"Malformed JSON request: {exc}", "final_state": "INVALID_INPUT", "fsm_trace": []}
                print(f"  Request received : malformed JSON ({exc})", flush=True)
                print("  Result           : INVALID_INPUT", flush=True)

        conn.sendall((json.dumps(response) + "\n").encode("utf-8"))
        print("  Response sent to client.", flush=True)
    except (socket.timeout, ConnectionError, OSError) as exc:
        print(f"Client {address[0]}:{address[1]} connection issue: {exc}", flush=True)
    finally:
        conn.close()


def main():
    print("============================================================================")
    print(f"                Electricity Efficiency Optimizer"                           )
    print("============================================================================")
    print(f"server listening on {HOST}:{PORT} \n ")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen(5)
        server.settimeout(1)
        try:
            while True:
                try:
                    conn, address = server.accept()
                except socket.timeout:
                    continue
                serve_client(conn, address)
        except KeyboardInterrupt:
            print("\nServer stopped.", flush=True)


if __name__ == "__main__":
    main()