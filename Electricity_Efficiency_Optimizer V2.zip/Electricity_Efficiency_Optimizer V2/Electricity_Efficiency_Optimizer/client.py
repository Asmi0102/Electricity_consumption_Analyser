import json
import socket
import sys
from pathlib import Path

from analyzer import DEFAULT_DATA

HOST, PORT = "127.0.0.1", 50515
WIDTH = 78


def line(char="-", width=WIDTH):
    print(char * width)


def section(title):
    print()
    line("=")
    print(f"  {title}")
    line("=")


def money(value):
    return f"₹{value:,.2f}"


def print_report(report):
    """Print the analysis report in readable sections."""
    print("\n" + "=" * WIDTH)
    print(" ELECTRICITY USAGE EFFICIENCY & COST OPTIMIZER".center(WIDTH))
    print(" HOUSEHOLD ANALYSIS REPORT".center(WIDTH))
    print("=" * WIDTH)

    print(f"  Billing period  : {report['billing_days']} days")
    print(f"  Electricity rate: {money(report['tariff_per_kwh'])} per kWh")
    print(f"  High-use limit  : {report['high_consumption_threshold_kwh']:.2f} kWh/day")
    print(f"  Final FSM state : {report['final_state']}")
    print("  FSM path        : " + " -> ".join(report["fsm_trace"]))

    section("1. CATEGORY-WISE ELECTRICITY USAGE")
    headers = ("Category", "Hours/day", "kWh/day", "Period kWh", "Period cost")
    data = [
        [
            r["category"],
            f"{r['hours_per_day']:.1f}",
            f"{r['daily_kwh']:.3f}",
            f"{r['period_kwh']:.2f}",
            money(r["period_cost"]),
        ]
        for r in report["categories"]
    ]

    widths = [
        max(len(headers[i]), *(len(row[i]) for row in data))
        for i in range(len(headers))
    ]

    print("  " + " | ".join(
        headers[i].ljust(widths[i]) for i in range(len(headers))
    ))
    print("  " + "-+-".join("-" * w for w in widths))

    for row in data:
        print("  " + " | ".join(
            row[i].ljust(widths[i]) for i in range(len(headers))
        ))

    section("2. OVERALL SUMMARY")
    summary = [
        ("Daily energy consumption",
         f"{report['total_daily_kwh']:.3f} kWh/day"),
        ("Billing-period consumption",
         f"{report['total_period_kwh']:.2f} kWh"),
        ("Estimated electricity bill",
         money(report["total_estimated_cost"])),
        ("Highest-consuming category",
         report["highest_consuming_category"]),
        ("High-consumption categories",
         ", ".join(report["high_consumption_categories"]) or "None"),
    ]

    label_width = max(len(label) for label, _ in summary)
    for label, value in summary:
        print(f"  {label:<{label_width}} : {value}")

    # Symbolic calculation appears before potential savings.
    section("3. SYMBOLIC CALCULATION (SymPy)")
    sym = report["symbolic_savings_example"]
    sub = sym["substitution"]

    print(f"  Example category  : {sym['category']}")
    print(f"  Formula           : {sym['expression']}")
    print("  Values substituted:")
    print(f"    Power           : {sub['power_w']} W")
    print(f"    Hours reduced   : {sub['hours_reduced']} hour(s)/day")
    print(f"    Billing days    : {sub['days']}")
    print(f"    Electricity rate: {money(sub['tariff_per_kwh'])}/kWh")
    print(f"  Example savings   : {money(sym['savings_cost'])}")

    section("4. POTENTIAL SAVINGS")
    print(f"  Energy savings        : {report['potential_savings_kwh']:.3f} kWh")
    print(f"  Estimated money saved : {money(report['potential_savings_cost'])}")
    print(f"  Bill after reduction  : {money(report['estimated_cost_after_reduction'])}")

    print("\n  Savings by category:")
    for row in report["categories"]:
        print(
            f"    - {row['category']:<18} "
            f"{row['potential_savings_kwh']:>8.3f} kWh  |  "
            f"{money(row['potential_savings_cost']):>12} saved"
        )

    section("5. ASSUMPTIONS AND LIMITATIONS")
    for item in report["assumptions"]:
        print(f"  • {item}")

    line("=")
    print("  Report generated successfully.".center(WIDTH))
    line("=")


def print_error(title, message, fsm_trace=None, final_state=None):
    """Display errors without printing raw Python dictionaries."""
    print("\n" + "!" * WIDTH)
    print(f" {title} ".center(WIDTH, "!"))
    line("!")
    print(f"  Error       : {message}")

    if final_state:
        print(f"  Final state : {final_state}")

    if fsm_trace:
        print("  FSM path    : " + " -> ".join(fsm_trace))

    line("!")


def main():
    # Read the optional JSON input file, or use the default dataset.
    try:
        request = (
            json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
            if len(sys.argv) > 1
            else DEFAULT_DATA
        )
        payload = (json.dumps(request) + "\n").encode("utf-8")

    except (OSError, json.JSONDecodeError) as exc:
        print_error("INPUT FILE ERROR", str(exc))
        sys.exit(1)

    print(f"\nConnecting to server at {HOST}:{PORT} ...")

    try:
        with socket.create_connection((HOST, PORT), timeout=5) as sock:
            print("Connected to server! \n Request Sent. \t Response Received... ")
            line()

            sock.settimeout(10)
            sock.sendall(payload)

            received = bytearray()
            while b"\n" not in received:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                received.extend(chunk)

        if not received:
            raise RuntimeError(
                "Server closed the connection without a response."
            )

        response_line = bytes(received).split(b"\n", 1)[0]
        report = json.loads(response_line.decode("utf-8"))

        if not report.get("ok"):
            print_error(
                "REQUEST COULD NOT BE ANALYZED",
                report.get("error", "Unknown error"),
                report.get("fsm_trace", []),
                report.get("final_state", "UNKNOWN"),
            )
            sys.exit(2)

        print_report(report)

    except ConnectionRefusedError:
        print_error(
            "CONNECTION REFUSED",
            "The server is not accepting connections at the specified address.",
        )
        print("  Start the server first with: python server.py")
        sys.exit(1)

    except socket.timeout:
        print_error(
            "CONNECTION TIMEOUT",
            "The connection or server response took too long.",
        )
        print("  Check that server.py is running and try again.")
        sys.exit(1)

    except (OSError, json.JSONDecodeError, ConnectionError, RuntimeError) as exc:
        print_error("CLIENT / CONNECTION ERROR", str(exc))
        print("  Check that server.py is running and the host/port match.")
        sys.exit(1)


if __name__ == "__main__":
    main()
