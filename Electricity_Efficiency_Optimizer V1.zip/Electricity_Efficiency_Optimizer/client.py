"""Interactive TCP client. Uses sample data unless a JSON file path is supplied."""
import json, socket, sys
from pathlib import Path
from analyzer import DEFAULT_DATA
HOST, PORT = "127.0.0.1", 50515

def main():
    try:
        request = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")) if len(sys.argv) > 1 else DEFAULT_DATA
        payload = (json.dumps(request) + "\n").encode("utf-8")
        with socket.create_connection((HOST, PORT), timeout=5) as sock:
            sock.settimeout(10); sock.sendall(payload)
            received = bytearray()
            while b"\n" not in received:
                chunk = sock.recv(4096)
                if not chunk: break
                received.extend(chunk)
        if not received: raise RuntimeError("Server closed the connection without a response.")
        report = json.loads(bytes(received).split(b"\n", 1)[0].decode("utf-8"))
        if not report.get("ok"):
            print("SERVER REPORTED AN ERROR:", report.get("error", "Unknown error"))
            print("FSM:", " -> ".join(report.get("fsm_trace", []))); return
        print("\nELECTRICITY USAGE EFFICIENCY AND COST OPTIMIZER")
        print("FSM:", " -> ".join(report["fsm_trace"]))
        print(f"Billing period: {report['billing_days']} days | Tariff: ₹{report['tariff_per_kwh']:.2f}/kWh")
        print("\nCategory-wise report")
        for row in report["categories"]:
            print(f"- {row['category']}: {row['daily_kwh']:.3f} kWh/day; {row['period_kwh']:.2f} kWh; cost ₹{row['period_cost']:.2f}; potential saving ₹{row['potential_savings_cost']:.2f}")
        print(f"\nDaily energy: {report['total_daily_kwh']:.3f} kWh")
        print(f"Billing-period energy: {report['total_period_kwh']:.2f} kWh")
        print(f"Estimated cost: ₹{report['total_estimated_cost']:.2f}")
        print(f"High-consumption categories: {', '.join(report['high_consumption_categories']) or 'None'}")
        print(f"Highest-consuming category: {report['highest_consuming_category']}")
        print(f"Potential savings: {report['potential_savings_kwh']:.2f} kWh / ₹{report['potential_savings_cost']:.2f}")
        print(f"Estimated cost after reduction: ₹{report['estimated_cost_after_reduction']:.2f}")
        sym = report["symbolic_savings_example"]
        print(f"SymPy example ({sym['category']}): {sym['expression']} = ₹{sym['savings_cost']:.2f} with substitutions {sym['substitution']}")
        print("\nAssumptions:"); [print("-", item) for item in report["assumptions"]]
    except (OSError, json.JSONDecodeError, socket.timeout, ConnectionError, RuntimeError) as exc:
        print(f"Client error: {exc}"); sys.exit(1)

if __name__ == "__main__": main()
