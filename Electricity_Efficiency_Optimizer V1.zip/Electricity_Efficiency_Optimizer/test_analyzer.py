import unittest
from copy import deepcopy
from analyzer import DEFAULT_DATA, analyze_household

class AnalyzerTests(unittest.TestCase):
    def setUp(self): self.data = deepcopy(DEFAULT_DATA)
    def test_normal_household_calculations(self):
        r = analyze_household(self.data)
        self.assertTrue(r["ok"]); self.assertEqual(r["final_state"], "REPORT_READY")
        self.assertAlmostEqual(r["total_daily_kwh"], 7.34, places=3)
        self.assertAlmostEqual(r["total_period_kwh"], 220.2, places=2)
        self.assertAlmostEqual(r["total_estimated_cost"], 1761.6, places=2)
        self.assertAlmostEqual(r["potential_savings_cost"], 372.0, places=2)
    def test_zero_reduction_has_zero_savings(self):
        for c in self.data["categories"]: c["reduce_hours_per_day"] = 0
        r = analyze_household(self.data)
        self.assertTrue(r["ok"]); self.assertEqual(r["potential_savings_cost"], 0)
        self.assertEqual(r["estimated_cost_after_reduction"], r["total_estimated_cost"])
    def test_invalid_hours_rejected_with_fsm(self):
        self.data["categories"][0]["hours_per_day"] = 25
        r = analyze_household(self.data)
        self.assertFalse(r["ok"]); self.assertEqual(r["final_state"], "INVALID_INPUT")
        self.assertIn("at most 24", r["error"])
        self.assertEqual(r["fsm_trace"][-1], "INVALID_INPUT")
    def test_high_consumption_category_detected(self):
        self.data["high_consumption_threshold_kwh"] = 1.0
        r = analyze_household(self.data)
        self.assertIn("Cooling", r["high_consumption_categories"])
        self.assertEqual(r["highest_consuming_category"], "Cooling")
    def test_zero_tariff(self):
        self.data["tariff_per_kwh"] = 0
        r = analyze_household(self.data)
        self.assertTrue(r["ok"]); self.assertEqual(r["total_estimated_cost"], 0)
    def test_missing_field_rejected(self):
        del self.data["tariff_per_kwh"]
        r = analyze_household(self.data)
        self.assertFalse(r["ok"]); self.assertIn("Missing required field", r["error"])

if __name__ == "__main__": unittest.main(verbosity=2)
