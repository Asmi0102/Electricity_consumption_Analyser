"""Newline-delimited JSON TCP server for the household optimizer."""
import json, socket
from analyzer import analyze_household
HOST = "127.0.0.1"
PORT = 50515
MAX_REQUEST_BYTES = 1_000_000

def serve_client(conn, address):
    conn.settimeout(10)
    try:
        chunks = bytearray()
        while b"\n" not in chunks and len(chunks) <= MAX_REQUEST_BYTES:
            part = conn.recv(4096)
            if not part:
                break
            chunks.extend(part)
        if len(chunks) > MAX_REQUEST_BYTES:
            response = {"ok": False, "error": "Request is too large.", "final_state": "INVALID_INPUT", "fsm_trace": ["WAITING_FOR_DATA", "DATA_CHECK", "INVALID_INPUT"]}
        elif not chunks.strip():
            response = {"ok": False, "error": "Empty request received.", "final_state": "INVALID_INPUT", "fsm_trace": ["WAITING_FOR_DATA", "DATA_CHECK", "INVALID_INPUT"]}
        else:
            line = bytes(chunks).split(b"\n", 1)[0]
            try:
                request = json.loads(line.decode("utf-8"))
                response = analyze_household(request)
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                response = {"ok": False, "error": f"Malformed JSON request: {exc}", "final_state": "INVALID_INPUT", "fsm_trace": ["WAITING_FOR_DATA", "DATA_CHECK", "INVALID_INPUT"]}
        conn.sendall((json.dumps(response) + "\n").encode("utf-8"))
    except (socket.timeout, ConnectionError, OSError) as exc:
        print(f"Client {address} connection issue: {exc}")
    finally:
        conn.close()

def main():
    print(f"Electricity Efficiency Optimizer server listening on {HOST}:{PORT}")
    print("Protocol: one UTF-8 JSON request terminated by newline; one JSON response per connection.")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT)); server.listen(5); server.settimeout(1)
        try:
            while True:
                try: conn, address = server.accept()
                except socket.timeout: continue
                serve_client(conn, address)
        except KeyboardInterrupt:
            print("\nServer stopped.")

if __name__ == "__main__": main()
