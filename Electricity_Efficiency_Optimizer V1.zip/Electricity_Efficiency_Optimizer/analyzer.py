"""Household electricity efficiency analysis, FSM validation, and SymPy savings."""
from functools import reduce
from numbers import Real
from sympy import symbols, simplify

DEFAULT_DATA = {
    "tariff_per_kwh": 8.0,
    "billing_days": 30,
    "high_consumption_threshold_kwh": 3.0,
    "categories": [
        {"name": "Cooling", "power_watts": 900, "hours_per_day": 5, "reduce_hours_per_day": 1},
        {"name": "Kitchen", "power_watts": 700, "hours_per_day": 2, "reduce_hours_per_day": 0.5},
        {"name": "Lighting", "power_watts": 120, "hours_per_day": 6, "reduce_hours_per_day": 1},
        {"name": "Entertainment", "power_watts": 180, "hours_per_day": 4, "reduce_hours_per_day": 1},
    ],
}

class AnalysisError(ValueError):
    """Raised when the request does not meet the input contract."""


def _number(value, label, *, minimum=None, maximum=None, strictly_positive=False):
    if isinstance(value, bool) or not isinstance(value, Real):
        raise AnalysisError(f"{label} must be a number.")
    if value != value:  # NaN
        raise AnalysisError(f"{label} must be finite.")
    value = float(value)
    if value in (float('inf'), float('-inf')):
        raise AnalysisError(f"{label} must be finite.")
    if strictly_positive and value <= 0:
        raise AnalysisError(f"{label} must be greater than zero.")
    if minimum is not None and value < minimum:
        raise AnalysisError(f"{label} must be at least {minimum}.")
    if maximum is not None and value > maximum:
        raise AnalysisError(f"{label} must be at most {maximum}.")
    return value


def validate_request(data):
    if not isinstance(data, dict):
        raise AnalysisError("Request must be a JSON object.")
    for field in ("categories", "tariff_per_kwh", "billing_days", "high_consumption_threshold_kwh"):
        if field not in data:
            raise AnalysisError(f"Missing required field: {field}.")
    if not isinstance(data["categories"], list) or not data["categories"]:
        raise AnalysisError("categories must be a non-empty list.")
    tariff = _number(data["tariff_per_kwh"], "tariff_per_kwh", minimum=0)
    if isinstance(data["billing_days"], bool) or not isinstance(data["billing_days"], int) or not 1 <= data["billing_days"] <= 366:
        raise AnalysisError("billing_days must be an integer from 1 to 366.")
    threshold = _number(data["high_consumption_threshold_kwh"], "high_consumption_threshold_kwh", minimum=0)
    seen = set()
    normalized = []
    for i, item in enumerate(data["categories"], start=1):
        if not isinstance(item, dict):
            raise AnalysisError(f"Category {i} must be an object.")
        name = item.get("name")
        if not isinstance(name, str) or not name.strip():
            raise AnalysisError(f"Category {i} name must not be empty.")
        name = name.strip()
        if name.casefold() in seen:
            raise AnalysisError(f"Category name '{name}' is duplicated.")
        seen.add(name.casefold())
        power = _number(item.get("power_watts"), f"{name}.power_watts", strictly_positive=True)
        hours = _number(item.get("hours_per_day"), f"{name}.hours_per_day", minimum=0, maximum=24)
        reduction = _number(item.get("reduce_hours_per_day", 0), f"{name}.reduce_hours_per_day", minimum=0)
        if reduction > 24:
            raise AnalysisError(f"{name}.reduce_hours_per_day must be at most 24.")
        normalized.append({"name": name, "power_watts": power, "hours_per_day": hours,
                           "reduce_hours_per_day": min(reduction, hours)})
    return {"categories": normalized, "tariff_per_kwh": tariff,
            "billing_days": data["billing_days"], "high_consumption_threshold_kwh": threshold}


def analyze_household(data):
    """Run an explicit FSM and return a JSON-serializable analysis report."""
    trace = ["WAITING_FOR_DATA", "DATA_CHECK"]
    try:
        clean = validate_request(data)
    except AnalysisError as exc:
        trace.append("INVALID_INPUT")
        return {"ok": False, "error": str(exc), "fsm_trace": trace, "final_state": "INVALID_INPUT"}

    trace.append("EFFICIENCY_ANALYSIS")
    days, tariff = clean["billing_days"], clean["tariff_per_kwh"]
    # map/lambda calculates daily category energy; zip preserves category order.
    daily_kwh = list(map(lambda c: c["power_watts"] * c["hours_per_day"] / 1000, clean["categories"]))
    rows = []
    for category, daily in zip(clean["categories"], daily_kwh):
        reduced_hours = min(category["hours_per_day"], category["reduce_hours_per_day"])
        saved_daily = category["power_watts"] * reduced_hours / 1000
        rows.append({
            "category": category["name"], "power_watts": category["power_watts"],
            "hours_per_day": category["hours_per_day"], "daily_kwh": round(daily, 4),
            "period_kwh": round(daily * days, 4), "period_cost": round(daily * days * tariff, 2),
            "reduction_hours_per_day": reduced_hours,
            "potential_savings_kwh": round(saved_daily * days, 4),
            "potential_savings_cost": round(saved_daily * days * tariff, 2),
            "cost_after_reduction": round((daily - saved_daily) * days * tariff, 2),
        })
    total_daily = reduce(lambda acc, x: acc + x, daily_kwh, 0.0)
    total_period = total_daily * days
    total_cost = total_period * tariff
    total_savings_kwh = reduce(lambda acc, row: acc + row["potential_savings_kwh"], rows, 0.0)
    total_savings_cost = reduce(lambda acc, row: acc + row["potential_savings_cost"], rows, 0.0)
    high = list(filter(lambda row: row["daily_kwh"] > clean["high_consumption_threshold_kwh"], rows))
    highest = max(rows, key=lambda row: row["daily_kwh"])
    # Symbolic formula and a concrete example using the first category's actual inputs.
    power_w, hours_reduced, days_symbol, rate = symbols("power_w hours_reduced days tariff_per_kwh", nonnegative=True)
    symbolic = simplify(power_w * hours_reduced * days_symbol * rate / 1000)
    first = clean["categories"][0]
    symbolic_example = {
        "category": first["name"], "expression": str(symbolic),
        "substitution": {"power_w": first["power_watts"], "hours_reduced": first["reduce_hours_per_day"],
                         "days": days, "tariff_per_kwh": tariff},
        "savings_cost": round(float(symbolic.subs({power_w:first["power_watts"], hours_reduced:first["reduce_hours_per_day"], days_symbol:days, rate:tariff})), 2),
    }
    trace.append("REPORT_READY")
    return {
        "ok": True, "fsm_trace": trace, "final_state": "REPORT_READY", "billing_days": days,
        "tariff_per_kwh": tariff, "high_consumption_threshold_kwh": clean["high_consumption_threshold_kwh"],
        "categories": rows, "total_daily_kwh": round(total_daily, 4),
        "total_period_kwh": round(total_period, 4), "total_estimated_cost": round(total_cost, 2),
        "high_consumption_categories": [row["category"] for row in high],
        "highest_consuming_category": highest["category"],
        "potential_savings_kwh": round(total_savings_kwh, 4),
        "potential_savings_cost": round(total_savings_cost, 2),
        "estimated_cost_after_reduction": round(total_cost - total_savings_cost, 2),
        "symbolic_savings_example": symbolic_example,
        "assumptions": ["Power is an estimated category-level average.", "Tariff remains constant throughout the billing period.",
                        "Fixed charges, taxes, and tiered tariffs are excluded.", "Savings assume reduced hours do not make usage negative."],
    }
