"""Run actual analyzer scenarios and print expected-vs-actual test report."""
from copy import deepcopy
from analyzer import DEFAULT_DATA, analyze_household

def cases():
    normal = deepcopy(DEFAULT_DATA)
    zero = deepcopy(DEFAULT_DATA)
    for c in zero["categories"]: c["reduce_hours_per_day"] = 0
    invalid = deepcopy(DEFAULT_DATA); invalid["categories"][0]["hours_per_day"] = 25
    high = deepcopy(DEFAULT_DATA); high["high_consumption_threshold_kwh"] = 1.0
    return [
        {"title":"Normal household data", "input":normal, "check":lambda r: r.get("ok") and r.get("final_state")=="REPORT_READY" and abs(r.get("total_daily_kwh",0)-7.34)<1e-6 and abs(r.get("total_estimated_cost",0)-1761.6)<1e-6 and abs(r.get("potential_savings_cost",0)-372.0)<1e-6, "expected":"REPORT_READY; daily 7.34 kWh; bill ₹1761.60; savings ₹372.00"},
        {"title":"Zero usage reduction", "input":zero, "check":lambda r: r.get("ok") and r.get("potential_savings_cost")==0 and r.get("final_state")=="REPORT_READY", "expected":"REPORT_READY; savings ₹0.00"},
        {"title":"Invalid operating hours", "input":invalid, "check":lambda r: not r.get("ok") and r.get("final_state")=="INVALID_INPUT" and "at most 24" in r.get("error", ""), "expected":"INVALID_INPUT; understandable hours validation error"},
        {"title":"High-consumption category", "input":high, "check":lambda r: r.get("ok") and "Cooling" in r.get("high_consumption_categories",[]) and r.get("highest_consuming_category")=="Cooling", "expected":"Cooling flagged; highest category Cooling"},
    ]

def main():
    passed = failed = 0
    print("ELECTRICITY EFFICIENCY OPTIMIZER — FORMATTED TEST REPORT")
    print("="*62)
    for i, case in enumerate(cases(), 1):
        actual = analyze_household(case["input"]); ok = bool(case["check"](actual))
        passed += int(ok); failed += int(not ok)
        print(f"\nTEST {i}: {case['title']}\n{'-'*62}")
        print("Input dataset:"); print(case["input"])
        print("Expected result:", case["expected"])
        print("Actual result:", {k:actual.get(k) for k in ("ok","final_state","total_daily_kwh","total_estimated_cost","potential_savings_cost","high_consumption_categories","highest_consuming_category","error") if k in actual})
        print("FSM trace:", " -> ".join(actual.get("fsm_trace", [])))
        if actual.get("error"): print("Validation error:", actual["error"])
        print("Status:", "PASS" if ok else "FAIL")
    total = passed + failed
    print("\n"+"="*62); print(f"Tests run: {total} | Passed: {passed} | Failed: {failed} | Pass percentage: {passed/total*100:.1f}%")
    return 0 if failed == 0 else 1

if __name__ == "__main__": raise SystemExit(main())
